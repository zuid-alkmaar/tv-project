import Slideshow from './components/Slideshow'

function App() {
  return <Slideshow />
}

export default App
